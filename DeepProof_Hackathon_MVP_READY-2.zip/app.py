import os
import tempfile
from datetime import datetime, timezone

import streamlit as st

from deepproof.analysis import analyze_file
from deepproof.report import make_report
from deepproof.ui import inject_css, status_badge

st.set_page_config(
    page_title="DeepProof | Digital Evidence Triage",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

inject_css()

if "analysis" not in st.session_state:
    st.session_state.analysis = None
if "case" not in st.session_state:
    st.session_state.case = None

st.markdown(
    '<div class="brand"><span>🛡️</span><div><h1>DeepProof</h1>'
    '<p>Preliminary Digital Evidence Triage</p></div></div>',
    unsafe_allow_html=True,
)

st.warning(
    "IMPORTANT: DeepProof is a preliminary triage prototype. "
    "It does not establish authenticity, authorship, admissibility, guilt or innocence, "
    "and it does not replace a qualified forensic examination."
)

with st.sidebar:
    st.header("Case Intake")
    case_id = st.text_input("Case ID", "CASE-2026-001")
    fir = st.text_input("FIR Number", "FIR-2026-001")
    station = st.text_input("Police Station", "Demo Police Station")
    target = st.text_input("Subject / Target", "Demo Subject")
    officer = st.text_input("Uploaded by", "Investigating Officer")

    st.divider()
    st.caption("MVP stack")
    st.caption("Streamlit • Python • OpenCV • FFprobe • ReportLab")
    st.caption("Real forensic model adapters can be plugged into the analysis layer.")

tab1, tab2, tab3 = st.tabs(["📤 Evidence Intake", "📊 Analysis", "📄 Report"])

with tab1:
    st.subheader("Evidence Intake")
    uploaded = st.file_uploader(
        "Upload original audio/video evidence",
        type=["mp4", "mov", "avi", "mkv", "webm", "mp3", "wav", "m4a"],
        help="For a real deployment, preserve the original file separately and perform analysis on a working copy.",
    )

    if uploaded:
        a, b, c = st.columns(3)
        a.metric("File", uploaded.name)
        b.metric("Size", f"{uploaded.size/1024/1024:.2f} MB")
        c.metric("Received", datetime.now().strftime("%d %b %Y, %H:%M"))

        if st.button("🚀 Start Preliminary Triage", type="primary", use_container_width=True):
            case = {
                "case_id": case_id,
                "fir": fir,
                "station": station,
                "target": target,
                "officer": officer,
                "filename": uploaded.name,
                "received_at": datetime.now(timezone.utc).isoformat(),
            }

            with tempfile.TemporaryDirectory() as td:
                path = os.path.join(td, uploaded.name)
                with open(path, "wb") as f:
                    f.write(uploaded.getbuffer())

                with st.status("Running evidence checks…", expanded=True) as status:
                    st.write("Generating SHA-256 fingerprint…")
                    st.write("Reading media/container metadata…")
                    st.write("Sampling media frames…")
                    st.write("Running preliminary consistency checks…")
                    result = analyze_file(path)
                    status.update(label="Triage complete", state="complete")

            st.session_state.analysis = result
            st.session_state.case = case
            st.success("Evidence triage completed. Open the Analysis tab.")

with tab2:
    if not st.session_state.analysis:
        st.info("Upload evidence and start triage first.")
    else:
        r = st.session_state.analysis

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Risk score", f'{r["risk_score"]}/100')
        c2.markdown(status_badge(r["classification"]), unsafe_allow_html=True)
        c3.metric("SHA-256", r["sha256"][:16] + "…")
        c4.metric("Duration", r["metadata"].get("duration", "N/A"))

        st.subheader("Evidence fingerprint")
        st.code(r["sha256"], language="text")

        st.subheader("Technical checks")
        cols = st.columns(len(r["checks"]))
        for col, (name, check) in zip(cols, r["checks"].items()):
            with col:
                st.markdown(f"**{name}**")
                st.markdown(status_badge(check["status"]), unsafe_allow_html=True)
                st.caption(check["message"])

        st.subheader("🚩 Review timestamps")
        if r["timestamps"]:
            for item in r["timestamps"]:
                st.error(
                    f'**{item["start"]} – {item["end"]}**  \n'
                    f'{item["reason"]}'
                )
        else:
            st.success("No high-risk timestamp was flagged by the current heuristic checks.")

        st.subheader("Metadata")
        st.json(r["metadata"])

        st.subheader("Findings")
        for item in r["findings"]:
            st.write("• " + item)

        st.info(
            "Interpretation: the score is a triage priority score, not a probability that the "
            "media is fake. Compression, re-encoding, screen recording and missing metadata "
            "can affect automated results."
        )

with tab3:
    if not st.session_state.analysis:
        st.info("Complete an analysis first.")
    else:
        st.subheader("Preliminary Report")
        st.write("Generate a PDF containing the case details, hash, checks, findings and limitations.")

        if st.button("📄 Generate PDF Report", type="primary", use_container_width=True):
            pdf = make_report(st.session_state.case, st.session_state.analysis)
            with open(pdf, "rb") as f:
                st.download_button(
                    "⬇️ Download DeepProof Report",
                    data=f,
                    file_name=f'{st.session_state.case["case_id"]}_DeepProof_Report.pdf',
                    mime="application/pdf",
                    use_container_width=True,
                )

st.divider()
st.caption(
    "Prototype for hackathon demonstration • Keep original evidence immutable • "
    "Use qualified forensic examination for disputed evidence."
)
