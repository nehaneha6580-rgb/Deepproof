# DeepProof Hackathon MVP

## Run locally

1. Install Python 3.10+.
2. Install FFmpeg so `ffprobe` is available.
3. Open this folder in Terminal/PowerShell.
4. Run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open the local Streamlit URL shown in the terminal.

## What is implemented

- Case intake
- Audio/video upload
- SHA-256 fingerprint
- FFprobe metadata extraction
- Lightweight video frame-consistency heuristic
- Basic audio/container check
- Timestamp flagging
- Risk-priority dashboard
- PDF report generation

## What is NOT claimed

The MVP does not contain a validated deepfake classifier. The score is a triage priority score, not a probability of manipulation.

## Next engineering layer

Add validated pretrained forensic models behind the functions in `deepproof/analysis.py`, then evaluate them on representative data before using any model output in a real investigative workflow.
