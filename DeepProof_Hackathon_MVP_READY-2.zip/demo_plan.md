# 3-minute hackathon demo

1. Introduce the problem:
   "An IO receives a disputed audio/video clip. The first question is where should the forensic team look?"

2. Upload a sample media file.

3. Show SHA-256:
   "We fingerprint the evidence before analysis."

4. Show the checks:
   Metadata → Audio → Frame consistency.

5. Show a flagged timestamp:
   "Instead of saying simply fake/real, we point the investigator to a segment for manual review."

6. Generate the PDF:
   "Every result is packaged into a traceable preliminary report."

7. Close:
   "DeepProof is not replacing the FSL. It is a triage layer that helps prioritize evidence and reduce unnecessary manual review."
