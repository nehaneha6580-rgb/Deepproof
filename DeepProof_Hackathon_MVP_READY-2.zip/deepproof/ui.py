import streamlit as st

def inject_css():
    st.markdown("""
    <style>
    .brand {display:flex; align-items:center; gap:14px; margin-bottom:8px;}
    .brand h1 {margin:0; font-size:2.2rem;}
    .brand p {margin:0; color:#8b949e;}
    .badge {display:inline-block; padding:7px 12px; border-radius:999px;
            font-weight:700; font-size:.9rem; margin-top:8px;}
    .green {background:#173b2a; color:#7ee2a8;}
    .yellow {background:#3f3515; color:#f4d35e;}
    .red {background:#4b2020; color:#ff9b9b;}
    </style>
    """, unsafe_allow_html=True)

def status_badge(text):
    t = text.lower()
    if "high" in t or "review" in t and "low" not in t:
        cls = "red"
    elif "warning" in t or "review" in t:
        cls = "yellow"
    else:
        cls = "green"
    return f'<span class="badge {cls}">{text}</span>'
