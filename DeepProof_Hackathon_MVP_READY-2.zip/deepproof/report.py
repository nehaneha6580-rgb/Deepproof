import os
import tempfile
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak

def make_report(case, result):
    path = os.path.join(tempfile.gettempdir(), f'{case["case_id"]}_DeepProof_Report.pdf')
    doc = SimpleDocTemplate(path, pagesize=A4, rightMargin=42, leftMargin=42, topMargin=42, bottomMargin=42)
    styles = getSampleStyleSheet()
    title = ParagraphStyle("Title", parent=styles["Title"], alignment=TA_CENTER, fontSize=20, leading=24)
    tiny = ParagraphStyle("Tiny", parent=styles["BodyText"], fontSize=8.5, leading=11)

    story = [
        Paragraph("DeepProof", title),
        Paragraph("Preliminary Digital Evidence Triage Report", styles["Heading2"]),
        Spacer(1, 12),
    ]

    rows = [
        ["Case ID", case["case_id"]],
        ["FIR", case["fir"]],
        ["Police Station", case["station"]],
        ["Subject", case["target"]],
        ["Uploaded By", case["officer"]],
        ["Evidence File", case["filename"]],
        ["SHA-256", result["sha256"]],
        ["Risk Score", f'{result["risk_score"]}/100'],
        ["Classification", result["classification"]],
    ]
    table = Table(rows, colWidths=[120, 380])
    table.setStyle(TableStyle([
        ("GRID", (0,0), (-1,-1), .5, colors.grey),
        ("BACKGROUND", (0,0), (0,-1), colors.lightgrey),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("FONTSIZE", (0,0), (-1,-1), 8.5),
    ]))
    story += [table, Spacer(1, 18), Paragraph("Technical Checks", styles["Heading2"])]

    for name, check in result["checks"].items():
        story.append(Paragraph(f'<b>{name}:</b> {check["status"]} — {check["message"]}', styles["BodyText"]))

    story += [Spacer(1, 12), Paragraph("Review Timestamps", styles["Heading2"])]
    if result["timestamps"]:
        for t in result["timestamps"]:
            story.append(Paragraph(f'{t["start"]} – {t["end"]}: {t["reason"]}', styles["BodyText"]))
    else:
        story.append(Paragraph("No high-risk timestamp was flagged by the current heuristics.", styles["BodyText"]))

    story += [Spacer(1, 12), Paragraph("Findings", styles["Heading2"])]
    for f in result["findings"]:
        story.append(Paragraph("• " + f, styles["BodyText"]))

    story += [
        PageBreak(),
        Paragraph("Limitations and Recommended Workflow", styles["Heading2"]),
        Paragraph(
            "This document is a preliminary technical triage output. It does not certify "
            "authenticity, authorship, admissibility, guilt or innocence. It is not a substitute "
            "for a qualified forensic examiner. Automated detection can be affected by compression, "
            "re-encoding, screen recordings, missing metadata, media quality and model limitations.",
            tiny,
        ),
        Spacer(1, 14),
        Paragraph(
            "<b>Recommended workflow:</b> preserve the original evidence; calculate and record a "
            "cryptographic hash; maintain chain-of-custody records; run preliminary triage on a "
            "working copy; identify suspicious segments; and refer disputed evidence for formal "
            "forensic examination when required.",
            tiny,
        ),
    ]

    doc.build(story)
    return path
