import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

import numpy as np

try:
    import cv2
except Exception:
    cv2 = None

VIDEO = {".mp4", ".mov", ".avi", ".mkv", ".webm"}
AUDIO = {".mp3", ".wav", ".m4a", ".aac"}

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def probe(path):
    if not shutil.which("ffprobe"):
        return {}
    cmd = ["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", path]
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
        return json.loads(out.decode("utf-8", errors="ignore"))
    except Exception:
        return {}

def metadata(path):
    data = probe(path)
    fmt = data.get("format", {})
    streams = data.get("streams", [])
    v = next((x for x in streams if x.get("codec_type") == "video"), {})
    a = next((x for x in streams if x.get("codec_type") == "audio"), {})
    duration = fmt.get("duration")
    try:
        duration = f"{float(duration):.2f}s" if duration else "N/A"
    except Exception:
        duration = "N/A"
    return {
        "container": fmt.get("format_name", "N/A"),
        "duration": duration,
        "file_size": f"{os.path.getsize(path)/1024/1024:.2f} MB",
        "video_codec": v.get("codec_name", "N/A"),
        "resolution": (
            f'{v.get("width")} × {v.get("height")}'
            if v.get("width") and v.get("height") else "N/A"
        ),
        "fps": v.get("r_frame_rate", "N/A"),
        "audio_codec": a.get("codec_name", "N/A"),
        "audio_sample_rate": a.get("sample_rate", "N/A"),
        "encoder": fmt.get("tags", {}).get("encoder", "N/A"),
    }

def fmt_time(seconds):
    seconds = max(0.0, float(seconds))
    m = int(seconds // 60)
    s = seconds % 60
    return f"{m:02d}:{s:05.2f}"

def frame_check(path):
    if cv2 is None or Path(path).suffix.lower() not in VIDEO:
        return {
            "status": "N/A",
            "message": "Video frame analysis unavailable for this file.",
            "score": 0,
            "timestamps": [],
        }

    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        return {"status": "N/A", "message": "Video could not be opened.", "score": 0, "timestamps": []}

    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration = total / fps if fps else 0

    if total < 5:
        cap.release()
        return {"status": "N/A", "message": "Too few frames for sampling.", "score": 0, "timestamps": []}

    indexes = np.linspace(0, total - 1, min(20, total)).astype(int)
    means, times = [], []
    for idx in indexes:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(idx))
        ok, frame = cap.read()
        if not ok:
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        means.append(float(gray.mean()))
        times.append(idx / fps)
    cap.release()

    if len(means) < 4:
        return {"status": "N/A", "message": "Could not sample enough frames.", "score": 0, "timestamps": []}

    diffs = np.abs(np.diff(means))
    baseline = float(np.median(diffs)) + 1e-6
    anomaly = float(np.max(diffs) / baseline)

    # Conservative triage heuristic, deliberately not a deepfake probability.
    score = int(np.clip((anomaly - 3.0) * 9.0, 0, 70))
    timestamps = []

    if anomaly >= 7:
        i = int(np.argmax(diffs))
        start = times[i]
        timestamps.append({
            "start": fmt_time(start),
            "end": fmt_time(min(start + max(1.0, duration / 20), duration)),
            "reason": "Abrupt sampled visual change; inspect this segment manually.",
        })

    return {
        "status": "⚠ Review" if score >= 30 else "✓ Passed",
        "message": "Lightweight frame-consistency heuristic; not a validated deepfake detector.",
        "score": score,
        "timestamps": timestamps,
    }

def audio_check(path):
    ext = Path(path).suffix.lower()
    meta = metadata(path)
    if ext not in VIDEO | AUDIO:
        return {"status": "N/A", "message": "Unsupported media.", "score": 0, "timestamps": []}

    score = 0
    if meta["audio_codec"] == "N/A":
        score = 8

    return {
        "status": "⚠ Review" if score else "✓ Detected",
        "message": "Audio stream/container check completed. Validated voice-cloning analysis is a future adapter.",
        "score": score,
        "timestamps": [],
    }

def metadata_check(meta):
    score = 0
    if meta["container"] == "N/A":
        score += 20
    if meta["encoder"] != "N/A":
        # Encoder presence is informational, not evidence of manipulation.
        pass
    return {
        "status": "⚠ Review" if score else "✓ Extracted",
        "message": "Basic container and stream metadata extracted.",
        "score": score,
        "timestamps": [],
    }

def analyze_file(path):
    sha = sha256_file(path)
    meta = metadata(path)
    checks = {
        "Metadata": metadata_check(meta),
        "Audio": audio_check(path),
        "Frame consistency": frame_check(path),
    }

    risk = int(np.clip(
        checks["Metadata"]["score"] * .20 +
        checks["Audio"]["score"] * .20 +
        checks["Frame consistency"]["score"] * .60,
        0, 100
    ))

    if risk >= 60:
        classification = "HIGH REVIEW PRIORITY"
    elif risk >= 30:
        classification = "REVIEW RECOMMENDED"
    else:
        classification = "LOW REVIEW PRIORITY"

    timestamps = []
    for check in checks.values():
        timestamps.extend(check["timestamps"])

    findings = [
        "SHA-256 fingerprint generated for the uploaded working copy.",
        "Basic container/stream metadata was extracted where available.",
        "Frame consistency was evaluated using a lightweight sampling heuristic.",
        "No automated result should be interpreted as a final forensic opinion.",
    ]
    if timestamps:
        findings.append("One or more segments were flagged for manual examination.")

    return {
        "sha256": sha,
        "metadata": meta,
        "checks": checks,
        "risk_score": risk,
        "classification": classification,
        "timestamps": timestamps,
        "findings": findings,
    }
