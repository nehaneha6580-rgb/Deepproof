import streamlit as st
import hashlib
import json
import re
from datetime import datetime, timezone
from io import BytesIO

st.set_page_config(
    page_title="DeepProof | Digital Evidence Triage",
    page_icon="🔎",
    layout="wide",
)

# -----------------------------
# Helpers
# -----------------------------
SUSPICIOUS_TERMS = {
    "forged": 18,
    "fake": 14,
    "tampered": 16,
    "altered": 12,
    "fraud": 14,
    "fraudulent": 14,
    "malware": 20,
    "phishing": 16,
    "stolen": 10,
    "counterfeit": 14,
    "unauthorized": 8,
    "deleted": 8,
    "edited": 6,
    "manipulated": 12,
    "fabricated": 16,
}

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def extract_text(uploaded_file, data: bytes) -> str:
    name = uploaded_file.name.lower()

    if name.endswith(".txt"):
        return data.decode("utf-8", errors="ignore")

    if name.endswith(".pdf"):
        try:
            from pypdf import PdfReader
            reader = PdfReader(BytesIO(data))
            pages = []
            for page in reader.pages:
                pages.append(page.extract_text() or "")
            return "\n".join(pages)
        except Exception:
            return ""

    if name.endswith(".docx"):
        try:
            from docx import Document
            doc = Document(BytesIO(data))
            return "\n".join(p.text for p in doc.paragraphs)
        except Exception:
            return ""

    return ""

def count_terms(text: str):
    lower = text.lower()
    hits = {}
    for term, weight in SUSPICIOUS_TERMS.items():
        count = len(re.findall(r"\b" + re.escape(term) + r"\b", lower))
        if count:
            hits[term] = count
    return hits

def calculate_score(filename, extension, size_mb, text, sha256):
    """
    Transparent preliminary triage score.
    It is NOT an authenticity verdict.
    """
    score = 5
    factors = []

    # File type / automatic-verification limitations
    review_types = {".mp4", ".mov", ".avi", ".mkv", ".mp3", ".wav", ".m4a"}
    if extension in review_types:
        score += 4
        factors.append("File type has limited automatic verification.")

    # File size
    if size_mb == 0:
        score += 35
        factors.append("File is empty.")
    elif size_mb < 0.01:
        score += 15
        factors.append("Very small file size.")
    elif size_mb > 100:
        score += 3
        factors.append("Large file requires additional technical review.")

    # Content signals
    hits = count_terms(text)
    for term, count in hits.items():
        score += min(count * SUSPICIOUS_TERMS[term], 25)

    if hits:
        factors.append(
            "Content contains potentially relevant integrity/fraud-related terms: "
            + ", ".join(f"{k} ({v})" for k, v in hits.items())
            + "."
        )

    # Text quality signals
    if text:
        if len(text.strip()) < 30:
            score += 8
            factors.append("Extracted text is very limited.")
        if "\x00" in text:
            score += 8
            factors.append("Unexpected binary/null characters detected in extracted text.")

    # Deterministic but file-specific variation, so identical baseline inputs
    # do not all receive exactly the same score.
    hash_adjustment = int(sha256[:2], 16) % 11
    score += hash_adjustment

    score = max(0, min(score, 100))
    confidence = max(0, 100 - score)

    if score >= 70:
        status = "HIGH ATTENTION"
    elif score >= 40:
        status = "REVIEW REQUIRED"
    else:
        status = "LOW INITIAL RISK"

    if not factors:
        factors.append("No strong automated warning signal detected in the available evidence.")

    return score, confidence, status, factors, hits

def build_report(result):
    return json.dumps(result, indent=2, ensure_ascii=False)

# -----------------------------
# Header
# -----------------------------
st.markdown(
    """
    <style>
    .hero {
        padding: 24px;
        border-radius: 18px;
        background: linear-gradient(135deg,#172554,#111827);
        border: 1px solid #334155;
        margin-bottom: 20px;
    }
    .hero h1 { color: white; margin: 0; }
    .hero p { color: #cbd5e1; margin-bottom: 0; }
    .small { color: #94a3b8; font-size: 0.9rem; }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="hero">
        <h1>🔎 DeepProof</h1>
        <p>Digital Evidence Triage — structured, transparent and review-ready.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.warning(
    "Prototype notice: DeepProof provides preliminary technical triage only. "
    "It does not establish authenticity, authorship, guilt or innocence."
)

# -----------------------------
# Sidebar / case registration
# -----------------------------
with st.sidebar:
    st.header("📋 Case Registration")

    case_id = st.text_input("Case ID", "CASE-2026-001")
    fir = st.text_input("FIR / Reference", "FIR-2026-001")
    station = st.text_input("Station / Police Station", "Demo Police Station")
    target = st.text_input("Subject / Target", "Demo Subject")
    officer = st.text_input("Investigating Officer", "Demo Officer")

    st.divider()
    st.caption("All fields are used to label the report. They do not change the technical score.")

tab1, tab2, tab3 = st.tabs(["📁 Evidence Intake", "🔍 Analysis", "📄 Report"])

# -----------------------------
# Evidence intake
# -----------------------------
with tab1:
    st.subheader("Upload Evidence")

    uploaded = st.file_uploader(
        "Choose an evidence file",
        type=["txt", "pdf", "docx", "jpg", "jpeg", "png", "mp4", "mov", "avi", "mkv", "mp3", "wav", "m4a"],
        help="Upload one evidence file for this prototype.",
    )

    if uploaded is None:
        st.info("Upload a file to start the technical triage.")
        st.session_state.pop("result", None)

    if uploaded is not None:
        data = uploaded.getvalue()
        filename = uploaded.name
        extension = "." + filename.rsplit(".", 1)[1].lower() if "." in filename else ""
        size_mb = len(data) / (1024 * 1024)
        sha256 = sha256_bytes(data)

        text = extract_text(uploaded, data)
        score, confidence, status, factors, hits = calculate_score(
            filename, extension, size_mb, text, sha256
        )

        result = {
            "case_id": case_id,
            "fir": fir,
            "station": station,
            "target": target,
            "officer": officer,
            "filename": filename,
            "extension": extension,
            "size_mb": round(size_mb, 3),
            "sha256": sha256,
            "risk_score": score,
            "confidence": confidence,
            "status": status,
            "content_signals": hits,
            "findings": factors,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        }
        st.session_state["result"] = result

        st.success("Evidence uploaded successfully.")

        c1, c2, c3 = st.columns(3)
        with c1:
            st.metric("File", filename)
        with c2:
            st.metric("Size", f"{size_mb:.2f} MB")
        with c3:
            st.metric("Risk Score", f"{score}/100")

        st.write("**SHA-256:**")
        st.code(sha256)

        st.write("**Initial Status:**", status)

# -----------------------------
# Analysis
# -----------------------------
with tab2:
    st.subheader("🔍 Technical Analysis")

    result = st.session_state.get("result")

    if not result:
        st.info("Upload evidence first.")
    else:
        score = result["risk_score"]
        status = result["status"]

        c1, c2 = st.columns(2)
        with c1:
            st.metric("Risk Score", f"{score}/100")
        with c2:
            st.metric("Initial Status", status)

        st.progress(score / 100)

        st.markdown("### Findings")
        for finding in result["findings"]:
            st.write("• " + finding)

        if result["content_signals"]:
            st.markdown("### Content Signals")
            for term, count in result["content_signals"].items():
                st.write(f"• `{term}` — {count} occurrence(s)")
        else:
            st.write("No suspicious content terms detected.")

        st.markdown("### Interpretation")
        if score >= 70:
            st.error(
                "High-attention result: multiple automated warning signals were detected. "
                "Human/forensic review is recommended."
            )
        elif score >= 40:
            st.warning(
                "Review-required result: some automated warning signals were detected. "
                "Do not treat this score as proof of tampering."
            )
        else:
            st.success(
                "Low-initial-risk result: no strong automated warning signal was detected. "
                "This does not prove authenticity."
            )

# -----------------------------
# Report
# -----------------------------
with tab3:
    st.subheader("📄 Review Report")

    result = st.session_state.get("result")

    if not result:
        st.info("Upload evidence first.")
    else:
        st.markdown("#### Case")
        st.write(
            f"**{result['case_id']}** · {result['fir']} · {result['station']}"
        )

        st.markdown("#### Evidence")
        st.write(
            f"**{result['filename']}** · {result['extension']} · "
            f"{result['size_mb']} MB"
        )

        st.markdown("#### Result")
        st.metric("Risk Score", f"{result['risk_score']}/100")
        st.write(f"**Status:** {result['status']}")
        st.write(f"**Confidence indicator:** {result['confidence']}/100")

        st.markdown("#### Findings")
        for finding in result["findings"]:
            st.write("• " + finding)

        report_json = build_report(result)

        st.download_button(
            "⬇️ Download JSON Report",
            data=report_json,
            file_name=f"DeepProof_{result['case_id']}_report.json",
            mime="application/json",
        )

        st.caption(
            "DeepProof is a preliminary technical triage prototype. "
            "A score is an attention indicator, not a legal or forensic conclusion."
        )
