# DeepProof

Digital Evidence Triage — a transparent preliminary technical screening prototype.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Current MVP
- Case registration
- Evidence upload
- SHA-256 hash
- File metadata
- PDF/TXT/DOCX text extraction
- Content-based warning signals
- File-specific deterministic risk score
- Risk status and findings
- JSON report download

The score is a preliminary attention indicator and does not establish authenticity, guilt, innocence, or authorship.
